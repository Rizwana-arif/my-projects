<?php

// include ("./include/connection.php");
// $del=$_GET['lawyerid'];
// $sql="SELECT `img` FROM `lawyers-rec` WHERE `lawyerid`='$del'";
// $run=mysqli_query($conn,$sql);
// $fet=mysqli_fetch_assoc($run);
//   //$pic=unserialize($fet['spic']);
//   //foreach($pic as $p){
//    // unlink("./pics/".$p);
//   //}
// unlink(".//".$fet['spic']);
//  $dsql="DELETE FROM `registration` WHERE `sname`='$del'";
//  $run=mysqli_query($conn,$dsql);
//  if($run){

//       header("Location:./singleselect_data.php");
//  }
include ("./include/header.php");
include ("./include/sidebar.php");
include ("./include/footer.php");
?>
