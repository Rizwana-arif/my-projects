<?php
$conn=mysqli_connect("localhost","root","","fyp-project");
if($conn){
    // echo "connected";
}else{
    echo "not connected";
}
?>