<?php 
$conn=mysqli_connect("localhost","root","","class-project");
if($conn){
    // echo "connected";
}else{
    echo "not connected";
}
?>