<?php 

?>

<footer class="main-footer">
        <div class="footer-left">
          <a href="templateshub.net">Developed By Rizwana</a></a>
        </div>
        <div class="footer-right">
        </div>
      </footer>
    </div>
  </div>  <!-- General JS Scripts -->
  <script src="./js/app.min.js"></script>
  <!-- JS Libraies -->
  <script src="./js/apexcharts.min.js"></script>
  <!-- Page Specific JS File -->
  <script src="./js/index.js"></script>
  <!-- Template JS File -->
  <script src="./js/scripts.js"></script>
  <!-- Custom JS File -->
  <script src="./js/custom.js"></script>

  <script src="./js/app.min.js"></script>
  <!-- JS Libraies -->
  <!-- Page Specific JS File -->
  <script src="./js/datatables.min.js"></script>
  <script src="./js/dataTables.bootstrap4.min.js"></script>
  <script src="./js/dataTables.buttons.min.js"></script>
  <script src="./js/buttons.flash.min.js"></script>
  <script src="./js/jszip.min.js"></script>
  <script src="./js/pdfmake.min.js"></script>
  <script src="./js/vfs_fonts.js"></script>
  <script src="./js/buttons.print.min.js"></script>
  <script src="./js/datatables.js"></script>
  
</body>


<!-- index.html  21 Nov 2019 03:47:04 GMT -->
</html>